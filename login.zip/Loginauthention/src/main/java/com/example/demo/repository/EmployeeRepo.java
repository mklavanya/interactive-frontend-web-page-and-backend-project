package com.example.demo.repository;

import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Employee;



public interface EmployeeRepo extends JpaRepository<Employee,Integer> {
	//optional introduced in java,convey the msg that there may be no value,without using null
	Optional<Employee>findByEmailAndPassword(String email,String password);
	Employee findByEmail(String email);
}
