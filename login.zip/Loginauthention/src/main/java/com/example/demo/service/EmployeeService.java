package com.example.demo.service;

import com.example.demo.dto.EmployeeDTO;
import com.example.demo.dto.LoginDTO;
import com.example.demo.responses.LoginResponses;


public interface EmployeeService {
	String addEmployee(EmployeeDTO employeeDTO );
	LoginResponses loginEmployee(LoginDTO loginDTO);
}
	
	

	
